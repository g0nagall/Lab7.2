public enum CustomerType {

    COMPANY,
    PERSON
}
